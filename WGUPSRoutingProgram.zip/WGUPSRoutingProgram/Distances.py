import csv
import datetime

# Read in csv file that is the mapping of distances between locations
with open('WGUPSDistanceTable .csv') as csvfile:
    readCSV = csv.reader(csvfile, delimiter=',')
    readCSV = list(readCSV)

# Read in csv file that is the names of delivery locations
with open('WGUNameAddressData.csv') as csvfile:
    name_readCSV = csv.reader(csvfile, delimiter=',')
    name_readCSV = list(name_readCSV)

    # a list of row/column values are inserted into this function, This function then calculates the total distance
    # that distance is then returned and each iteration represents a distance between two locations
    # Space-time complexity is O(1)


def check_distance(row_value, column_value, sum_of_distance):
    distance = readCSV[row_value][column_value]
    if distance is '':
        distance = readCSV[column_value][row_value]
        return sum_of_distance + float(distance)


# this function  return a current distance
# Space-time complexity is O(1)
def check_current_distance(row_value, column_value):
    distance = readCSV[row_value][column_value]
    if distance == '':
        distance = readCSV[column_value][row_value]
    return float(distance)
    # This is the time that the first truck leaves the hub


# this function calculate the time for every delivery and added to the previous time
# The total represents the total time used.
# runtime of function is O(N)

def check_time(distance, truck_list):  # truck list is
    new_time = distance / 18
    distance_in_minutes_second = '{0:02.0f}:{1:02.0f}'.format(*divmod(new_time * 3600, 60))
    final_time = '00:' + distance_in_minutes_second
    truck_list.append(final_time)

    total = datetime.timedelta()
    for i in truck_list:
        print(truck_list)
        (h, m, s) = i.split(':')
        d = datetime.timedelta(hours=int(h), minutes=int(m), seconds=int(s))
        total += d
        print(str(total))
        return total


# this function gets package address data
# Space-time complexity is O(1)
def check_address():
    return name_readCSV


# this lists represents the sorted trucks that are put in order of efficiency in the function below
first_optimized_truck = []
first_optimized_truck_index_list = []
second_optimized_truck = []
second_optimized_truck_index_list = []
third_optimized_truck = []
third_optimized_truck_index_list = []


# This is my sorting algorithm that uses a greedy approach to automate optimizing the delivery route for each truck.
# This algorithm takes 3 parameters (see section 1)
# First parameter is the list of packages on a truck that has not been optimized yet
# The second parameter represents the truck number
# The third parameter represents the current location that is updated each time a truck moves


# The first loop is to find the shortest distance to next location. The shortest distance value will be assigned to
# lowest_value, which will continually change until a minimum value is found. The second loop indicates what will
# happen when a lowest_value is found. shortest is. Condition statement will determine the trunk number . Values are
# appended to the appropriate truck list and the current location is assigned to the next optimal location. A recursive
# call is made for the next location and shortened the list. Recursive calls will continually be made until the base
# case is called, which will end the function and return the empty list .

# The space-time complexity of this algorithm is O(N^2).

def calculate_shortest_distance(truck_package_list, truck_number, current_location):  # section 1
    if len(truck_package_list) == 0:  # section 2
        return truck_package_list
    lowest_value = 50.0
    new_location = 0

    for i in truck_package_list:
        value = int(i[1])
        if check_current_distance(current_location, value) <= lowest_value:
            lowest_value = check_current_distance(current_location, value)
            new_location = value

    for i in truck_package_list:
        value = int(i[1])
        if check_current_distance(current_location, value) == lowest_value:
            if truck_number == 1:
                first_optimized_truck.append(i)
                first_optimized_truck_index_list.append(i[1])
                pop_value = truck_package_list.index(i)
                truck_package_list.pop(pop_value)
                current_location = new_location
                calculate_shortest_distance(truck_package_list, 1, current_location)
            elif truck_number == 2:
                second_optimized_truck.append(i)
                second_optimized_truck_index_list.append(i[1])
                pop_value = truck_package_list.index(i)
                truck_package_list.pop(pop_value)
                current_location = new_location
                calculate_shortest_distance(truck_package_list, 2, current_location)

            elif truck_number == 3:
                third_optimized_truck.append(i)
                third_optimized_truck_index_list.append(i[1])
                pop_value = truck_package_list.index(i)
                truck_package_list.pop(pop_value)
                current_location = new_location
                calculate_shortest_distance(truck_package_list, 3, current_location)


first_optimized_truck_index_list.insert(0, '0')


# Space-time complexity is O(1)
def first_optimized_truck_index():
    return first_optimized_truck_index_list

    # Space-time complexity is O(1)


def first_optimized_truck_list():
    return first_optimized_truck


second_optimized_truck_index_list.insert(0, '0')


# Space-time complexity is O(1)
def second_optimized_truck_index():
    return second_optimized_truck_index_list


# Space-time complexity is O(1)
def second_optimized_truck_list():
    return second_optimized_truck


third_optimized_truck_index_list.insert(0, '0')


# Space-time complexity is O(1)
def third_optimized_truck_index():
    return third_optimized_truck_index_list


# Space-time complexity is O(1)
def third_optimized_truck_list():
    return third_optimized_truck
