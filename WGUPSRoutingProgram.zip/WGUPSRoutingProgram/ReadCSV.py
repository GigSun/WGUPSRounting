import csv
from HashTable import HashMap

with open('WGUPackageData.csv') as csvfile:
    readCSV = csv.reader(csvfile, delimiter=',')
    insert_into_hash_table = HashMap()  # Calls the Hashmap to create an object of hashmap
    first_delivery = []  # list that represents the first truck delivery
    second_delivery = []  # list that represents the second truck delivery
    first_truck_second_delivery = []  # list that represents the final truck delivery

    # Read in values from CSV file and insert them into key/values pairs
    # these values are what makes up the dictionary inside of the Hash table
    # Space-time complexity is O(N)
    for row in readCSV:
        packageID = row[0]
        address = row[1]
        city = row[2]
        state = row[3]
        zipcode = row[4]
        delivery = row[5]
        size = row[6]
        note = row[7]
        delivery_start = ''
        address_location = ''
        delivery_status = 'At hub'
        iterate_value = [packageID, address_location, address, city, state,
                         zipcode, delivery, size, note, delivery_start,
                         delivery_status]
        key = packageID
        value = iterate_value
        # In place constraints to create  a list of packages that are loaded onto the trucks
        # The data structure here focuses on moving all attributes of a package into a nested list
        # This allows for quick lookup and sorting that can be based on every package detail
        # Below is the set of constraints that determine which packages are loaded in either of the two trucks.
        if value[0] == '19':
            first_delivery.append(value)  # load package #19 to the first truck per note
        if value[6] != 'EOD':
            if 'Must' in value[8] or 'None' in value[8]:
                first_delivery.append(value)  # this is a list that represents the first truck
        if 'Can only be' in value[8]:
            second_delivery.append(value)
        if 'Delayed' in value[8]:
            second_delivery.append(value)
        # change the wrong address package to the correct address

        if 'Wrong address listed' in value[8]:
            value[2] = '410 S State St'
            value[5] = '84111'
            first_truck_second_delivery.append(value)

        if value not in first_delivery and value not in second_delivery and value not in first_truck_second_delivery:
            if len(second_delivery) > len(first_truck_second_delivery):
                first_truck_second_delivery.append(value)
            else:
                second_delivery.append(value)

        insert_into_hash_table.insert(key, value)  # add all values in csv file to a hash table

    # function used to get the full list of values at start of day
    # Space-time complexity is O(1)
    def get_hash_map():
        return insert_into_hash_table

    # function used to grab the packages that are loaded into the second truck
    # Space-time complexity is O(1)
    def get_second_truck_first_trip():
        return second_delivery

    # function used to grab the packages that are loaded into the first truck last
    # Space-time complexity is O(1)
    def get_first_truck_second_trip():
        return first_truck_second_delivery

    # function used to grab the packages that are loaded into the first truck last
    # Space-time complexity is O(1)
    def get_first_truck_first_trip():
        return first_delivery
