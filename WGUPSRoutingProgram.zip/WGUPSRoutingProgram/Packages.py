import Distances
import ReadCSV

# Empty lists created
first_delivery = []
second_delivery = []
third_delivery = []
first_truck_distance_list = []
second_truck_distance_list = []
third_truck_distance_list = []
# the times below represent the time that each truck leaves the hub
first_leave_time = ['8:00:00']
second_leave_time = ['9:05:00']
third_leave_time = ['11:00:00']

# for loop updates the delivery status of all packages in truck 1 to when the truck leaves the station
# for loop add appropriate packages to the first_delivery list
# Space-time complexity is O(N)

for i, value in enumerate(ReadCSV.get_first_truck_first_trip()):
    ReadCSV.get_first_truck_first_trip()[i][9] = first_leave_time[0]
    first_delivery.append(ReadCSV.get_first_truck_first_trip()[i])
    i += 1

# this for loop compares truck1 address to address list
# update the address_location in the package value[1]
# Space_time complexity is O(N^2)
try:
    first_variable_count = 0
    for k in first_delivery:
        for j in Distances.check_address():
            if k[2] == j[2]:
                first_truck_distance_list.append(j[0])
                first_delivery[first_variable_count][1] = j[0]
                first_variable_count += 1

except IndexError:
    pass

# calls to the greedy algorithm that sorts the packages in a more efficient order
Distances.calculate_shortest_distance(first_delivery, 1, 0)
first_truck_total_distance = 0

# this for loop takes the values in the first truck ands runs them through the distance functions in the Distance.py
# file Space-time complexity is O(N)

for index in range(len(Distances.first_optimized_truck_index())):  # index range 0-13, len is 14

    try:
        # calculate the total distance of the truck
        first_truck_total_distance = Distances.check_distance(int(Distances.first_optimized_truck_index()[index]),
                                                              int(Distances.first_optimized_truck_index()[index + 1]),
                                                              first_truck_total_distance)
        print(first_truck_total_distance)
        # calculate the distance of each package along the route
        deliver_package = Distances.check_time(
            Distances.check_current_distance(int(Distances.first_optimized_truck_index()[index]),
                                             int(Distances.first_optimized_truck_index()[index + 1])), first_leave_time)

        Distances.first_optimized_truck_list()[index][10] = (str(deliver_package))
        ReadCSV.get_hash_map().update(int(Distances.first_optimized_truck_list()[index][0]),
                                      first_delivery)

    except IndexError:
        pass

# for loop updates the delivery status of all packages in truck 2 to when the truck leaves the station
# for loop add appropriate packages to the second_delivery list
# Space-time complexity is O(N)

for i, value in enumerate(ReadCSV.get_second_truck_first_trip()):
    ReadCSV.get_second_truck_first_trip()[i][9] = second_leave_time
    second_delivery.append(ReadCSV.get_second_truck_first_trip()[i])
    i += 1

# this for loop compares the address on truck two to the list of addresses and adds the address index to the list
# Space_time complexity is O(N^2)
try:
    second_variable_count = 0
    for k in second_delivery:
        for j in Distances.check_address():
            if k[2] == j[2]:
                second_truck_distance_list.append(j[0])
                second_delivery[second_variable_count][1] = j[0]
                second_variable_count += 1

except IndexError:
    pass

# calls to the greedy algorithm that sorts the packages in a more efficient order
Distances.calculate_shortest_distance(second_delivery, 2, 0)
second_truck_total_distance = 0

# this for loop takes the values in the second truck ands runs them through the distance functions in the Distance.py
# file Space-time complexity is O(N)

for index in range(len(Distances.second_optimized_truck_index())):
    try:
        # calculate the total distance of the truck
        second_truck_total_distance = Distances.check_distance(int(Distances.second_optimized_truck_index()[index]),
                                                               int(Distances.second_optimized_truck_index()[index + 1]),
                                                               second_truck_total_distance)
        # calculate the distance of each package along the route
        deliver_package = Distances.check_time(
            Distances.check_current_distance(int(Distances.second_optimized_truck_index()[index]),
                                             int(Distances.second_optimized_truck_index()[
                                                     index + 1])), second_leave_time)
        Distances.second_optimized_truck_list()[index][10] = (str(deliver_package))
        ReadCSV.get_hash_map().update(int(Distances.second_optimized_truck_list()[index][0]),
                                      second_delivery)

    except IndexError:
        pass

    # for loop updates the delivery status of all packages in truck 1 2nd delivery to when the truck leaves the station
    # for loop add appropriate packages to the final_delivery list
    # Space-time complexity is O(N)

    for i, value in enumerate(ReadCSV.get_first_truck_second_trip()):
        ReadCSV.get_first_truck_second_trip()[i][9] = third_leave_time
        third_delivery.append(ReadCSV.get_first_truck_second_trip()[i])
        i += 1

# this for loop compares the address on truck on one to the list of addresses and adds the address index to the list
# Space_time complexity is O(N^2)
try:
    third_variable_count = 0
    for k in third_delivery:
        for j in Distances.check_address():
            if k[2] == j[2]:
                third_truck_distance_list.append(j[0])
                third_delivery[third_variable_count][1] = j[0]
                third_variable_count += 1

except IndexError:
    pass

# calls to the greedy algorithm that sorts the packages in a more efficient order
Distances.calculate_shortest_distance(third_delivery, 3, 0)
third_truck_total_distance = 0

# this for loop takes the values in the third truck ands runs them through the distance functions in the Distance.py
# file Space-time complexity is O(N)

for index in range(len(Distances.third_optimized_truck_index())):
    try:
        # calculate the total distance of the truck
        third_truck_total_distance = Distances.check_distance(int(Distances.third_optimized_truck_index()[index]),
                                                              int(Distances.third_optimized_truck_index()[index + 1]),
                                                              third_truck_total_distance)
        # calculate the distance of each package along the route
        deliver_package = Distances.check_time(
            Distances.check_current_distance(int(Distances.third_optimized_truck_index()[index]),
                                             int(Distances.third_optimized_truck_index()[index + 1])), third_leave_time)
        Distances.third_optimized_truck_list()[index][10] = (str(deliver_package))
        ReadCSV.get_hash_map().update(int(Distances.third_optimized_truck_list()[index][0]),
                                      third_delivery)

    except IndexError:
        pass


# function returns total distance of all 3 trips to calculate the distance of all packages
# Space-time complexity is O(1)
def total_distance():
    return first_truck_total_distance + second_truck_total_distance + third_truck_total_distance
